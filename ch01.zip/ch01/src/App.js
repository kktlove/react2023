import './App.css';
//1. 기본 컴포넌트 편집
function App() {
  return (
    <div className="App">
      <h2 className="title">Hello React~! Hi GT~!</h2>
      <p className="comment">안녕하세요~! 리액트입니다.</p>
    </div>
  );
}
//jsx = js + xml => babel
export default App;
