//표현식과 내부 스타일링, 인라인 스타일링, 조건 연산자, if 문을 활용하여 컴포넌트 만들기
const Test2 = () => {
  return (
    <div className="App">

    </div>
  )
}

export default Test2