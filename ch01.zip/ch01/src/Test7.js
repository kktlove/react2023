//비구조 할당
const Test7 = ({irum, age, addr}) => {
  return (
    <div class="App">
        <h1>비구조 할당</h1>
        <h2>저의 이름은 {irum} 입니다.</h2>
        <h2>나이는 {age}세 입니다.</h2>
        <h2>사는 곳은 {addr} 입니다.</h2>
        <hr />
    </div>
  )
}

export default Test7